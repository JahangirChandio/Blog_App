package com.rober.blogapp.ui.main.feed

interface OnMoveRecyclerListener {
    fun onMove()
}