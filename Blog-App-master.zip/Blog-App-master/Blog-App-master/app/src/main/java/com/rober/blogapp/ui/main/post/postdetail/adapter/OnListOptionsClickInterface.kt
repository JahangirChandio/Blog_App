package com.rober.blogapp.ui.main.post.postdetail.adapter

interface OnListOptionsClickInterface {
    fun onClickListOption(position: Int)
}