package com.rober.blogapp.util

import android.graphics.Bitmap

object MotionUtils {

    val MOTION_TRANSITION_END = 2131230891
    val MOTION_TRANSITION_START = 2131231110

//    fun getDominantColors(bitmap: Bitmap) : Int {
//        val newBitmap = Bitmap.createScaledBitmap(bitmap, 1, 1, true)
//        val color = newBitmap.getPixel(0, 0)
//        newBitmap.recycle()
//        return color
//    }
}

