package com.rober.blogapp.ui.main.profile.profiledetail.utils

object ProfileUserCodes {

    val EMPTY_USER_PROFILE = 0
    val CURRENT_USER_PROFILE = 1
    val OTHER_USER_PROFILE = 2
}