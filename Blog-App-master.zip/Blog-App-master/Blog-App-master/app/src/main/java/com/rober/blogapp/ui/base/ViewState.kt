package com.rober.blogapp.ui.base

interface ViewState {
}