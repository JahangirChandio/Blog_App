package com.rober.blogapp.util

data class MessageUtil(val message: String) {
}