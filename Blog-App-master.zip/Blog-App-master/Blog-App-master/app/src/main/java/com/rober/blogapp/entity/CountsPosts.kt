package com.rober.blogapp.entity

data class CountsPosts(val countPosts: Int) {
    constructor() : this(0)
}