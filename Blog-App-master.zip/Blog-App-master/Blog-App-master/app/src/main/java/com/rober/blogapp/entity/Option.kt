package com.rober.blogapp.entity

data class Option(val icon: Int, val text: String) {


}