package com.rober.blogapp.ui.main.post.postdetail.utils

object ArrayUtils {
    val FOLLOW = 0
    val UNFOLLOW = 1
}