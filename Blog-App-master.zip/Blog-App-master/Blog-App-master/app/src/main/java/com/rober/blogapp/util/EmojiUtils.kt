package com.rober.blogapp.util

object EmojiUtils {
    val OK_HAND = 0x1F44C
    val ANGUISHED_FACE = 0x1F627
}