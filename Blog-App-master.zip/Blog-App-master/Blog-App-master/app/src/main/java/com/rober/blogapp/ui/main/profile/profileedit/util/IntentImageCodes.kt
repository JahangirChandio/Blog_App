package com.rober.blogapp.ui.main.profile.profileedit.util

object IntentImageCodes {

    val PROFILE_IMAGE_CODE = 1
    val BACKGROUND_IMAGE_CODE = 2
}